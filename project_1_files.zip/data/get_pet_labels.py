from os import listdir

def get_pet_labels(image_dir):
    """
    Creates a dictionary of pet labels (results_dic) based upon the filenames 
    of the image files. These pet image labels are used to check the accuracy 
    of the labels that are returned by the classifier function, since the 
    filenames of the images contain the true identity of the pet in the image.
    Be sure to format the pet labels so that they are in all lower case letters
    and with leading and trailing whitespace characters stripped from them.
    (ex. filename = 'Boston_terrier_02259.jpg' Pet label = 'boston terrier')
    Parameters:
     image_dir - The (full) path to the folder of images that are to be
                 classified by the classifier function (string)
    Returns:
      results_dic - Dictionary with 'key' as image filename and 'value' as a 
      List. The list contains for following item:
         index 0 = pet image label (string)
    """
    # Creates list of files in directory
    in_files = listdir(image_dir)
    
    # Creates empty dictionary for the results (pet labels, etc.)
    results_dic = dict()
   
    # Processes through each file in the directory, extracting only the words
    # of the file that contain the pet image label
    for idx in range(0, len(in_files), 1):
       
       # Skips file if starts with . (like .DS_Store of Mac OSX) because it 
       # isn't an pet image file
       if in_files[idx][0] != ".":
           
           # Extracts the pet label from the filename
           pet_label = ""
           # Splits filename by '_' to remove extension and separate words
           pet_label_words = in_files[idx].split('_')
           
           # Loops through each word in the list of words
           for word in pet_label_words:
               # Check if word is alphanumeric (excluding numbers)
               if word.isalpha():
                   # Concatenates valid words to form pet label
                   pet_label += word.lower() + " "
                   
           # Strips leading/trailing whitespace characters from the pet_label
           pet_label = pet_label.strip()
           
           # If filename doesn't already exist in dictionary add it and its
           # pet label - otherwise print an error message because it indicates 
           # duplicate files (filenames)
           if in_files[idx] not in results_dic:
              results_dic[in_files[idx]] = [pet_label]
           else:
               print("** Warning: Duplicate files exist in directory:", 
                     in_files[idx])
 
    # Returns the results dictionary
    return results_dic
